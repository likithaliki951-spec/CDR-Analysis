 CDR Forensic Analysis System

Python GUI-based telecom call detail record analysis dashboard.

Features
- CDR analysis
- Suspicious call detection
- Graph generation
- Excel export
- CSV upload support

 Technologies
- Python
- PyQt5
- Pandas
- Matplotlib
